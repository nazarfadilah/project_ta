# Petunjuk Singkat untuk Pengembang — Apps-Asrama

Ringkasan cepat berisi konvensi, cara jalanin project, dan catatan penting yang diambil dari semua file `docs/` dan kode di repo. Ditujukan untuk developer yang ingin bekerja pada `apps/web` dan paket UI (shadcn).

## Quick start (local)
- Buka terminal, masuk ke folder app: `cd apps/web`
- Install deps: `npm install`
- Siapkan environment: salin `.env.example` ke `.env` dan set `DATABASE_URL`.
  - Contoh DB lokal (development): `mysql://root:@localhost:3306/260403-apps-asrama`
- Generate Prisma client: `npx prisma generate`
- Sinkronkan schema ke DB (dev):
  - Prefer: `npx prisma migrate dev --name init` (dev migrations)
  - Alternatif cepat: `npm run db:push` (gunakan hanya untuk dev)
- Seed data awal: `npm run db:seed` (jalan dari `apps/web` — script menjalankan `tsx prisma/seed.ts`)
- Jalankan dev server: `npm run dev`
- Buka Prisma Studio: `npm run db:studio` atau `npx prisma studio`

## Kode & lokasi penting
- Next.js App: `apps/web/app/` (App Router)
- Prisma schema: `apps/web/prisma/schema.prisma`
- Prisma client wrapper: `apps/web/lib/prisma.ts`
- Seed script: `apps/web/prisma/seed.ts`
- Package UI (shadcn): `packages/ui/src` dan `apps/web/components/ui`
- Komponen umum: `apps/web/components/sections` dan `apps/web/components/ui`

## Konvensi utama (singkat)
- Primary keys: UUID (gunakan `crypto.randomUUID()` di seed dan server).
- Jangan pakai prefix di UUID; simpan sebagai murni UUID.
- Prisma: project saat ini menggunakan Prisma v5 (jika ingin upgrade, baca breaking changes v7 — constructor/adapter berbeda).
- Environment: `DATABASE_URL` disimpan di `apps/web/.env` dan schema membaca `env("DATABASE_URL")`.
- Passwords: hash dengan `bcryptjs` (salt rounds 10).
- MediaLink: gunakan relasi eksplisit saat query (misal `facilityId`, `postId`, `assetId`) — jangan andalkan polymorphic magic.
- Occupancy rules (implementasi wajib):
  - Salah satu dari `guestId` atau `kloterId` harus ada (XOR).
  - `checkOutTime` hanya terisi bila status = `CHECKED_OUT`.
  - `facility.genderPolicy` harus cocok dengan gender guest saat check-in di HAJJ_SEASON.
- String constants: gunakan nilai persis yang ada di `docs/DATABASE_DESIGN.md` (contoh: facility `status` harus `AVAILABLE|MAINTENANCE|FULL|DISABLED` — jangan ubah ejaan).

## Prisma & migration notes
- Development: gunakan `npx prisma migrate dev --name <desc>` untuk membuat migration dan `npx prisma generate` setelah perubahan schema.
- Production: gunakan `npx prisma migrate deploy`.
- Jika butuh reset cepat selama pengembangan: `npx prisma db push --force-reset` (HATI-HATI: destructive).
- Setelah update schema, selalu jalankan `npx prisma generate` dan cek `apps/web/lib/prisma.ts` singleton pattern.

## Seed
- File: `apps/web/prisma/seed.ts`.
- Menjalankan: dari `apps/web`: `npm run db:seed`.
- Pastikan tidak menggunakan string ID literal; seed telah diubah ke `randomUUID()`.
- Script seed mencetak kredensial admin dev (cek console output ketika seed selesai).

## UI — shadcn pattern
- Ikuti pola komponen di `packages/ui/src` dan `apps/web/components/ui`.
- Gunakan Theme Provider (`theme-provider.tsx`) dan `use client` untuk komponen yang butuh state.
- Komponen harus kecil, teruji, dan dipasang di `components/ui` untuk reuse.

## Windows / PowerShell notes
- Jika npm script ter-block oleh ExecutionPolicy di PowerShell, jalankan di `cmd.exe` atau set ExecutionPolicy sementara:
  - `Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process`
- Alternatif: jalankan perintah `npx prisma ...` langsung di cmd.

## Developer workflow & PR
- Branch: `feature/<singkat-deskripsi>` atau `fix/<singkat>`.
- Commit kecil & atomik; deskripsikan prisma schema changes di body commit.
- Jika mengubah schema: tambahkan migration (`npx prisma migrate dev`) dan sertakan migration files di PR.
- Setelah merge ke main/staging: jalankan `npx prisma migrate deploy` di env staging/production.
- Pastikan linter & typecheck lulus sebelum PR: `npm run lint` dan `npm run build`.

## Quick reminders
- DB: MySQL 8+ direkomendasikan; charset `utf8mb4`.
- Timezone: aplikasi memakai Asia/Jakarta (cek `SystemSetting` jika perlu override).
- Jangan commit secrets (gunakan `.env` yang di-ignore oleh git).
- Jika upgrade Prisma ke versi mayor, baca release notes dan cek penggunaan `PrismaClient` constructor, adapter, dan `datasourceUrl` changes.

---
File ini dibuat dari ringkasan dokumen `docs/*` dan inspeksi cepat pada folder `apps/web`. Jika mau, saya bisa:
- Memperluas menjadi checklist onboarding developer lengkap; atau
- Menambahkan contoh perintah deploy/migration terperinci untuk staging/production.

